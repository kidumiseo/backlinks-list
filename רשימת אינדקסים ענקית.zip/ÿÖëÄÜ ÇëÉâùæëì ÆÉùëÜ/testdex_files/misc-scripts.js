// nprogress.min.js (minified)
!function(n){"function"==typeof module?module.exports=n():"function"==typeof define&&define.amd?define(n):this.NProgress=n()}(function(){function n(n,t,e){return t>n?t:n>e?e:n}function t(n){return 100*(-1+n)}function e(n,e,r){var i;return i="translate3d"===c.positionUsing?{transform:"translate3d("+t(n)+"%,0,0)"}:"translate"===c.positionUsing?{transform:"translate("+t(n)+"%,0)"}:{"margin-left":t(n)+"%"},i.transition="all "+e+"ms "+r,i}function r(n,t){var e="string"==typeof n?n:o(n);return e.indexOf(" "+t+" ")>=0}function i(n,t){var e=o(n),i=e+t;r(e,t)||(n.className=i.substring(1))}function s(n,t){var e,i=o(n);r(n,t)&&(e=i.replace(" "+t+" "," "),n.className=e.substring(1,e.length-1))}function o(n){return(" "+(n.className||"")+" ").replace(/\s+/gi," ")}function a(n){n&&n.parentNode&&n.parentNode.removeChild(n)}var u={};u.version="0.1.3";var c=u.settings={minimum:.08,easing:"ease",positionUsing:"",speed:200,trickle:!0,trickleRate:.02,trickleSpeed:800,showSpinner:!0,barSelector:'[role="bar"]',spinnerSelector:'[role="spinner"]',template:'<div class="bar" role="bar"><div class="peg"></div></div><div class="spinner" role="spinner"><div class="spinner-icon"></div></div>'};u.configure=function(n){var t,e;for(t in n)e=n[t],void 0!==e&&n.hasOwnProperty(t)&&(c[t]=e);return this},u.status=null,u.set=function(t){var r=u.isStarted();t=n(t,c.minimum,1),u.status=1===t?null:t;var i=u.render(!r),s=i.querySelector(c.barSelector),o=c.speed,a=c.easing;return i.offsetWidth,l(function(n){""===c.positionUsing&&(c.positionUsing=u.getPositioningCSS()),f(s,e(t,o,a)),1===t?(f(i,{transition:"none",opacity:1}),i.offsetWidth,setTimeout(function(){f(i,{transition:"all "+o+"ms linear",opacity:0}),setTimeout(function(){u.remove(),n()},o)},o)):setTimeout(n,o)}),this},u.isStarted=function(){return"number"==typeof u.status},u.start=function(){u.status||u.set(0);var n=function(){setTimeout(function(){u.status&&(u.trickle(),n())},c.trickleSpeed)};return c.trickle&&n(),this},u.done=function(n){return n||u.status?u.inc(.3+.5*Math.random()).set(1):this},u.inc=function(t){var e=u.status;return e?("number"!=typeof t&&(t=(1-e)*n(Math.random()*e,.1,.95)),e=n(e+t,0,.994),u.set(e)):u.start()},u.trickle=function(){return u.inc(Math.random()*c.trickleRate)},function(){var n=0,t=0;u.promise=function(e){return e&&"resolved"!=e.state()?(0==t&&u.start(),n++,t++,e.always(function(){t--,0==t?(n=0,u.done()):u.set((n-t)/n)}),this):this}}(),u.render=function(n){if(u.isRendered())return document.getElementById("nprogress");i(document.documentElement,"nprogress-busy");var e=document.createElement("div");e.id="nprogress",e.innerHTML=c.template;var r,s=e.querySelector(c.barSelector),o=n?"-100":t(u.status||0);return f(s,{transition:"all 0 linear",transform:"translate3d("+o+"%,0,0)"}),c.showSpinner||(r=e.querySelector(c.spinnerSelector),r&&a(r)),document.body.appendChild(e),e},u.remove=function(){s(document.documentElement,"nprogress-busy");var n=document.getElementById("nprogress");n&&a(n)},u.isRendered=function(){return!!document.getElementById("nprogress")},u.getPositioningCSS=function(){var n=document.body.style,t="WebkitTransform"in n?"Webkit":"MozTransform"in n?"Moz":"msTransform"in n?"ms":"OTransform"in n?"O":"";return t+"Perspective"in n?"translate3d":t+"Transform"in n?"translate":"margin"};var l=function(){function n(){var e=t.shift();e&&e(n)}var t=[];return function(e){t.push(e),1==t.length&&n()}}(),f=function(){function n(n){return n.replace(/^-ms-/,"ms-").replace(/-([\da-z])/gi,function(n,t){return t.toUpperCase()})}function t(n){var t=document.body.style;if(n in t)return n;for(var e,r=i.length,s=n.charAt(0).toUpperCase()+n.slice(1);r--;)if(e=i[r]+s,e in t)return e;return n}function e(e){return e=n(e),s[e]||(s[e]=t(e))}function r(n,t,r){t=e(t),n.style[t]=r}var i=["Webkit","O","Moz","ms"],s={};return function(n,t){var e,i,s=arguments;if(2==s.length)for(e in t)i=t[e],void 0!==i&&t.hasOwnProperty(e)&&r(n,e,i);else r(n,s[1],s[2])}}();return u});

// WOW - v0.1.6 - 2014-03-19
(function(){var a,b=function(a,b){return function(){return a.apply(b,arguments)}};a=function(){function a(){}return a.prototype.extend=function(a,b){var c,d;for(c in a)d=a[c],null!=d&&(b[c]=d);return b},a.prototype.isMobile=function(a){return/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(a)},a}(),this.WOW=function(){function c(a){null==a&&(a={}),this.scrollCallback=b(this.scrollCallback,this),this.scrollHandler=b(this.scrollHandler,this),this.start=b(this.start,this),this.scrolled=!0,this.config=this.util().extend(a,this.defaults)}return c.prototype.defaults={boxClass:"wow",animateClass:"animated",offset:0,mobile:!0},c.prototype.init=function(){var a;return this.element=window.document.documentElement,"interactive"===(a=document.readyState)||"complete"===a?this.start():document.addEventListener("DOMContentLoaded",this.start)},c.prototype.start=function(){var a,b,c,d;if(this.boxes=this.element.getElementsByClassName(this.config.boxClass),this.boxes.length){if(this.disabled())return this.resetStyle();for(d=this.boxes,b=0,c=d.length;c>b;b++)a=d[b],this.applyStyle(a,!0);return window.addEventListener("scroll",this.scrollHandler,!1),window.addEventListener("resize",this.scrollHandler,!1),this.interval=setInterval(this.scrollCallback,50)}},c.prototype.stop=function(){return window.removeEventListener("scroll",this.scrollHandler,!1),window.removeEventListener("resize",this.scrollHandler,!1),null!=this.interval?clearInterval(this.interval):void 0},c.prototype.show=function(a){return this.applyStyle(a),a.className=""+a.className+" "+this.config.animateClass},c.prototype.applyStyle=function(a,b){var c,d,e;return d=a.getAttribute("data-wow-duration"),c=a.getAttribute("data-wow-delay"),e=a.getAttribute("data-wow-iteration"),a.setAttribute("style",this.customStyle(b,d,c,e))},c.prototype.resetStyle=function(){var a,b,c,d,e;for(d=this.boxes,e=[],b=0,c=d.length;c>b;b++)a=d[b],e.push(a.setAttribute("style","visibility: visible;"));return e},c.prototype.customStyle=function(a,b,c,d){var e;return e=a?"visibility: hidden; -webkit-animation-name: none; -moz-animation-name: none; animation-name: none;":"visibility: visible;",b&&(e+="-webkit-animation-duration: "+b+"; -moz-animation-duration: "+b+"; animation-duration: "+b+";"),c&&(e+="-webkit-animation-delay: "+c+"; -moz-animation-delay: "+c+"; animation-delay: "+c+";"),d&&(e+="-webkit-animation-iteration-count: "+d+"; -moz-animation-iteration-count: "+d+"; animation-iteration-count: "+d+";"),e},c.prototype.scrollHandler=function(){return this.scrolled=!0},c.prototype.scrollCallback=function(){var a;return this.scrolled&&(this.scrolled=!1,this.boxes=function(){var b,c,d,e;for(d=this.boxes,e=[],b=0,c=d.length;c>b;b++)a=d[b],a&&(this.isVisible(a)?this.show(a):e.push(a));return e}.call(this),!this.boxes.length)?this.stop():void 0},c.prototype.offsetTop=function(a){var b;for(b=a.offsetTop;a=a.offsetParent;)b+=a.offsetTop;return b},c.prototype.isVisible=function(a){var b,c,d,e,f;return c=a.getAttribute("data-wow-offset")||this.config.offset,f=window.pageYOffset,e=f+this.element.clientHeight-c,d=this.offsetTop(a),b=d+a.clientHeight,e>=d&&b>=f},c.prototype.util=function(){return this._util||(this._util=new a)},c.prototype.disabled=function(){return!this.config.mobile&&this.util().isMobile(navigator.userAgent)},c}()}).call(this);

// MISC SCRIPTS
jQuery(function($){

	// FLIP EFFECT
	$('div.hover').live({mouseenter: function(){$(this).addClass('flip');},mouseleave: function(){$(this).removeClass('flip');}});	
	
	// SHOW STUFF ON CLICK
	$('.clickshow').click(function() {
		var hidethis = '.' + $(this).attr('hidethis'); $(hidethis).slideUp(); 
		var showthis = '.' + $(this).attr('showthis'); $(showthis).slideToggle(); 
	});	
	
	// SHOW STUFF ON CLICK (BY ID)
	$('.clickshowid').click(function() {
		var hidethis = '.' + $(this).attr('hidethis'); $(hidethis).slideUp(); 
		var showthis = '#' + $(this).attr('showthis'); $(showthis).slideToggle(); 
	});	
	
	// SHOW STUFF ON HOVER
	$('.hovershow').hover(function() {var showthis = '#' + $(this).attr('showthis');$(showthis).slideToggle();});

	
	$('.tip').tooltip();			// KICKSTART BOOTSTRAP TOOLTIP
	$('#homemainslider').carousel();
	
	// REMOVE UNWANTED JQUERY FUNCTIONS FOR SHORCODES
	$("div#removebr br, .removebr br").remove();
	$("div#removep p, .removep p").each(function() {var $this = $(this); if($this.html().replace(/\s|&nbsp;/g, '').length == 0) $this.remove();	});
	$('div#removep > p, .removep > p').filter(function() {return $.trim($(this).text()) === '' && $(this).children().length == 0}).remove()

	$('.debugthis').click(function() {$('.debugdata').slideToggle();})	// MAKE DEBUGGIN WORK!
	
	// NPROGRESS
	$('body').show();
	$('.version').text(NProgress.version);
	NProgress.start();
	setTimeout(function() { NProgress.done(); $('.fade').removeClass('out'); }, 1000);

	$("#b-0").click(function() { NProgress.start(); });
	$("#b-40").click(function() { NProgress.set(0.4);});
	$("#b-60").click(function() { NProgress.set(0.6);});
	$("#b-80").click(function() { NProgress.set(0.8);});
	$("#b-inc").click(function() { NProgress.inc();});
	$("#b-100").click(function() { NProgress.done();});	
	
});


jQuery(document).ready(function($) {

	// SWING SHARE BOX
	$('.shareTheLove').slideDown();
	$('.shareTheLove').hover(function() {
		$(this).addClass('animated swing');
	}, function() {
		$(this).removeClass('animated swing');
	});
	
	
	new WOW().init();
	
	// sidebar contact affix
	if($('.customWidget').length > 0) {
		$('.customWidget').affix({
			offset: { top: $('.customWidget').offset().top }
		});
	}	
	
	
	// TOOGLE BOX
	$(".linkToogle .title").click(function() {
	
		var itemid			=	$(this).parent().attr('showthis');
		var boxitem			=	'#box' + itemid;
		var showthis		=	'#data' + itemid;
		var itemhelper		=	'#minimizWidget' + itemid;
		
		$(itemhelper).toggleClass("minClose");
		$(showthis).slideToggle("fast");
		
		var currentClass = $(itemhelper).attr("class");
		if(currentClass == "minOpen") {$(boxitem).find("span#status").text("-");} 
		else {$(boxitem).find("span#status").text("+");}
		
	});
	
	
	// ANIMATED SCROLL TO - EXAMPLE: <div class="scroll" scrollto="objectid"></div>
	$('.scroll').click(function() {
		var scrollto 	= '#' + $(this).attr('scrollto'); 
		$("html, body").animate({ scrollTop: $(scrollto).offset().top - 125 + 'px' }, 1000);
		window.location.hash = $(this).attr('scrollto');	
	});
	
	
	// SHOW SCROLL TOP WHEN NEEDED
	$(window).on('scroll', function () {
		var scrollTop     = $(window).scrollTop();
		var elementOffset = $('.bodyContainer').offset().top;
		var distance      = (elementOffset - scrollTop);

			if(distance < 0) {$('.scrolltop').fadeIn();}
			else if(distance > 30) {$('.scrolltop').fadeOut();}
			
		//$('.longSlogan').html(distance);
	});
	
	
});



// jquery-toastmessage-plugin (minified)
(function(e){var t={inEffect:{opacity:"show"},inEffectDuration:600,stayTime:5e3,text:"",sticky:false,type:"notice",position:"top-left",closeText:"",close:null};var n={init:function(n){if(n){e.extend(t,n)}},showToast:function(n){var r={};e.extend(r,t,n);var i,s,o,u,a;i=!e(".toast-container").length?e("<div></div>").addClass("toast-container").addClass("toast-position-"+r.position).appendTo("body"):e(".toast-container");s=e("<div></div>").addClass("toast-item-wrapper");o=e("<div></div>").hide().addClass("toast-item toast-type-"+r.type).appendTo(i).html(e("<p>").append(r.text)).animate(r.inEffect,r.inEffectDuration).wrap(s);u=e("<div></div>").addClass("toast-item-close").prependTo(o).html(r.closeText).click(function(){e().toastmessage("removeToast",o,r)});a=e("<div></div>").addClass("toast-item-image").addClass("toast-item-image-"+r.type).prependTo(o);if(navigator.userAgent.match(/MSIE 6/i)){i.css({top:document.documentElement.scrollTop})}if(!r.sticky){setTimeout(function(){e().toastmessage("removeToast",o,r)},r.stayTime)}return o},showNoticeToast:function(t){var n={text:t,type:"notice"};return e().toastmessage("showToast",n)},showSuccessToast:function(t){var n={text:t,type:"success"};return e().toastmessage("showToast",n)},showErrorToast:function(t){var n={text:t,type:"error"};return e().toastmessage("showToast",n)},showWarningToast:function(t){var n={text:t,type:"warning"};return e().toastmessage("showToast",n)},removeToast:function(e,t){e.animate({opacity:"0"},600,function(){e.parent().animate({height:"0px"},300,function(){e.parent().remove()})});if(t&&t.close!==null){t.close()}}};e.fn.toastmessage=function(t){if(n[t]){return n[t].apply(this,Array.prototype.slice.call(arguments,1))}else if(typeof t==="object"||!t){return n.init.apply(this,arguments)}else{e.error("Method "+t+" does not exist on jQuery.toastmessage")}}})(jQuery)